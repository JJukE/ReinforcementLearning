Javascript Animation exporter for matplotlib and IPython


