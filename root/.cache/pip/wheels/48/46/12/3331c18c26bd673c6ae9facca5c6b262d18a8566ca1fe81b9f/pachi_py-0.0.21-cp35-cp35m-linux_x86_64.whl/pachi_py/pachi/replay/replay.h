#ifndef PACHI_REPLAY_REPLAY_H
#define PACHI_REPLAY_REPLAY_H

#include "engine.h"

struct engine *engine_replay_init(char *arg, struct board *b);

#endif
