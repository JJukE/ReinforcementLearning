#include <stdbool.h>

int debug_level = 0;
bool debug_boardprint = false;
long verbose_logs = 0;
int seed;
