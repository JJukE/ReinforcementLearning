#ifndef PACHI_PATTERNSCAN_PATTERNSCAN_H
#define PACHI_PATTERNSCAN_PATTERNSCAN_H

#include "engine.h"

struct engine *engine_patternscan_init(char *arg, struct board *b);

#endif
