#ifndef PACHI_JOSEKI_JOSEKI_H
#define PACHI_JOSEKI_JOSEKI_H

#include "engine.h"

struct engine *engine_joseki_init(char *arg, struct board *b);

#endif
